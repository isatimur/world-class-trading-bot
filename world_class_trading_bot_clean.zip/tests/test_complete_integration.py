#!/usr/bin/env python3
"""
Complete Integration Test

This script tests all components working together:
- Bybit integration
- Natural language translation
- Trading strategies
- Configuration management
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

from trading_bot.tools.bybit_trading_tool import BybitTradingTool
from trading_bot.tools.natural_language_translator import (
    NaturalLanguageTranslator,
    translate_trading_signal,
    get_market_advice
)
from trading_bot.config.settings import Settings
from trading_bot.strategies import GridStrategy, MLStrategy, MomentumStrategy
from trading_bot.utils.logging import get_logger

logger = get_logger(__name__)


async def test_bybit_connection():
    """Test Bybit connection and market data."""
    print("🔗 Testing Bybit Connection...")
    
    try:
        async with BybitTradingTool(testnet=True) as bybit:
            # Test market data
            ticker = await bybit.get_ticker("BTCUSDT")
            if ticker['success']:
                price = float(ticker['data']['list'][0]['lastPrice'])
                print(f"✅ Bybit connected - BTCUSDT: ${price:,.2f}")
                return True
            else:
                print(f"❌ Bybit connection failed: {ticker['error']}")
                return False
    except Exception as e:
        print(f"❌ Bybit connection error: {e}")
        return False


async def test_natural_language_translation():
    """Test natural language translation."""
    print("\n🗣️ Testing Natural Language Translation...")
    
    try:
        # Test signal translation
        response = await translate_trading_signal(
            symbol="BTCUSDT",
            signal_type="BUY",
            price=62000.0,
            confidence=0.85,
            strategy="Grid Strategy",
            technical_indicators={"rsi": 35.2, "macd": "bullish"},
            market_context={"sentiment": "bullish"},
            reasoning="Price at support level with oversold RSI"
        )
        
        print(f"✅ Signal translation working: {response.summary}")
        return True
        
    except Exception as e:
        print(f"❌ Natural language translation error: {e}")
        return False


async def test_trading_strategies():
    """Test trading strategies creation."""
    print("\n📊 Testing Trading Strategies...")
    
    try:
        # Test Grid Strategy
        grid_strategy = GridStrategy(
            strategy_id="test_grid",
            symbol="BTCUSDT",
            grid_levels=10,
            grid_spacing_pct=0.02,
            initial_capital=1000.0,
            risk_per_trade=0.01
        )
        print(f"✅ Grid Strategy created: {grid_strategy.strategy_id}")
        
        # Test ML Strategy
        ml_strategy = MLStrategy(
            strategy_id="test_ml",
            symbol="ETHUSDT",
            feature_lookback=50,
            prediction_horizon=5,
            initial_capital=1000.0,
            risk_per_trade=0.015
        )
        print(f"✅ ML Strategy created: {ml_strategy.strategy_id}")
        
        # Test Momentum Strategy
        momentum_strategy = MomentumStrategy(
            strategy_id="test_momentum",
            symbol="SOLUSDT",
            short_period=10,
            long_period=30,
            initial_capital=1000.0,
            risk_per_trade=0.02
        )
        print(f"✅ Momentum Strategy created: {momentum_strategy.strategy_id}")
        
        return True
        
    except Exception as e:
        print(f"❌ Trading strategies error: {e}")
        return False


async def test_configuration():
    """Test configuration management."""
    print("\n⚙️ Testing Configuration...")
    
    try:
        # Test settings
        print(f"✅ Google API Key: {Settings.GOOGLE_API_KEY[:10]}...")
        print(f"✅ Bybit API Key: {Settings.BYBIT_API_KEY[:10]}...")
        print(f"✅ Telegram Token: {Settings.TELEGRAM_BOT_TOKEN[:10]}...")
        print(f"✅ Trading Mode: {Settings.TRADING_MODE}")
        print(f"✅ Risk Tolerance: {Settings.RISK_TOLERANCE}")
        
        return True
        
    except Exception as e:
        print(f"❌ Configuration error: {e}")
        return False


async def test_combined_workflow():
    """Test complete workflow from market data to natural language."""
    print("\n🔄 Testing Combined Workflow...")
    
    try:
        # Step 1: Get market data from Bybit
        async with BybitTradingTool(testnet=True) as bybit:
            ticker = await bybit.get_ticker("BTCUSDT")
            if ticker['success']:
                price = float(ticker['data']['list'][0]['lastPrice'])
                change_24h = float(ticker['data']['list'][0]['price24hPcnt']) * 100
                
                print(f"📊 Market Data: BTCUSDT ${price:,.2f} ({change_24h:+.2f}%)")
                
                # Step 2: Generate trading signal
                if change_24h > 5:
                    signal_type = "BUY"
                    confidence = 0.75
                    reasoning = f"Strong positive momentum with {change_24h:.1f}% gain"
                elif change_24h < -5:
                    signal_type = "SELL"
                    confidence = 0.70
                    reasoning = f"Negative momentum with {change_24h:.1f}% loss"
                else:
                    signal_type = "HOLD"
                    confidence = 0.60
                    reasoning = f"Sideways movement with {change_24h:.1f}% change"
                
                # Step 3: Translate to natural language
                response = await translate_trading_signal(
                    symbol="BTCUSDT",
                    signal_type=signal_type,
                    price=price,
                    confidence=confidence,
                    strategy="Momentum Analysis",
                    technical_indicators={
                        "rsi": 50.0 + (change_24h * 2),
                        "macd": "bullish" if change_24h > 0 else "bearish",
                        "trend": "uptrend" if change_24h > 0 else "downtrend"
                    },
                    market_context={
                        "market_sentiment": "bullish" if change_24h > 0 else "bearish",
                        "volatility": "high" if abs(change_24h) > 5 else "moderate"
                    },
                    reasoning=reasoning,
                    risk_level="HIGH" if abs(change_24h) > 10 else "MODERATE"
                )
                
                print(f"🎯 Signal: {response.summary}")
                print(f"💡 Action: {response.action_recommendation}")
                print(f"⚠️ Risk: {response.risk_assessment}")
                
                return True
            else:
                print(f"❌ Failed to get market data: {ticker['error']}")
                return False
                
    except Exception as e:
        print(f"❌ Combined workflow error: {e}")
        return False


async def test_market_advice():
    """Test market advice generation."""
    print("\n💡 Testing Market Advice Generation...")
    
    try:
        # Get market context from Bybit
        async with BybitTradingTool(testnet=True) as bybit:
            symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT']
            market_context = {
                "current_prices": {},
                "market_sentiment": "neutral",
                "volatility": "moderate"
            }
            
            for symbol in symbols:
                ticker = await bybit.get_ticker(symbol)
                if ticker['success']:
                    ticker_data = ticker['data'].get('list', [])
                    if ticker_data:
                        price = float(ticker_data[0]['lastPrice'])
                        change_24h = float(ticker_data[0]['price24hPcnt']) * 100
                        market_context["current_prices"][symbol] = {
                            "price": price,
                            "change_24h": change_24h
                        }
            
            # Generate market advice
            advice = await get_market_advice(market_context)
            
            print("✅ Market advice generated successfully!")
            print(f"📝 Advice length: {len(advice)} characters")
            
            return True
            
    except Exception as e:
        print(f"❌ Market advice error: {e}")
        return False


async def main():
    """Main test function."""
    print("🚀 Complete Integration Test")
    print("=" * 60)
    
    # Test 1: Configuration
    config_test = await test_configuration()
    
    # Test 2: Bybit Connection
    bybit_test = await test_bybit_connection()
    
    # Test 3: Natural Language Translation
    nlp_test = await test_natural_language_translation()
    
    # Test 4: Trading Strategies
    strategy_test = await test_trading_strategies()
    
    # Test 5: Combined Workflow
    workflow_test = await test_combined_workflow()
    
    # Test 6: Market Advice
    advice_test = await test_market_advice()
    
    print("\n" + "=" * 60)
    print("🎉 Complete Integration Test Results")
    print("\n📋 Summary:")
    print(f"✅ Configuration: {'PASS' if config_test else 'FAIL'}")
    print(f"✅ Bybit Connection: {'PASS' if bybit_test else 'FAIL'}")
    print(f"✅ Natural Language: {'PASS' if nlp_test else 'FAIL'}")
    print(f"✅ Trading Strategies: {'PASS' if strategy_test else 'FAIL'}")
    print(f"✅ Combined Workflow: {'PASS' if workflow_test else 'FAIL'}")
    print(f"✅ Market Advice: {'PASS' if advice_test else 'FAIL'}")
    
    all_tests_passed = all([
        config_test, bybit_test, nlp_test, 
        strategy_test, workflow_test, advice_test
    ])
    
    if all_tests_passed:
        print("\n🎯 ALL SYSTEMS WORKING TOGETHER PERFECTLY!")
        print("✅ Bybit integration: Real-time market data")
        print("✅ Google Agent SDK: Natural language translation")
        print("✅ Trading strategies: Grid, ML, Momentum")
        print("✅ Configuration: All settings loaded")
        print("✅ Combined workflow: End-to-end functionality")
        print("✅ Market advice: AI-powered recommendations")
        print("\n🚀 READY FOR PRODUCTION DEPLOYMENT!")
    else:
        print("\n❌ Some tests failed - check configuration")
    
    return all_tests_passed


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1) 