#!/usr/bin/env python3
"""
Test Bybit Integration

This script tests the Bybit integration to see if it's working
with the market and can fetch real data.
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

from trading_bot.tools.bybit_trading_tool import BybitTradingTool
from trading_bot.config.settings import Settings

async def test_bybit_market_data():
    """Test Bybit market data fetching."""
    print("🧪 Testing Bybit Market Data...")
    
    try:
        async with BybitTradingTool(testnet=True) as bybit:
            # Test getting market data for BTCUSDT
            print("📊 Fetching BTCUSDT market data...")
            market_data = await bybit.get_market_data("BTCUSDT", interval="1", limit=10)
            
            if market_data['success']:
                print("✅ Market data fetched successfully")
                data = market_data['data'].get('list', [])
                if data:
                    latest = data[0]
                    print(f"   Latest BTCUSDT price: ${float(latest[4]):,.2f}")
                    print(f"   Volume: {float(latest[5]):,.0f}")
                    print(f"   Data points: {len(data)}")
                else:
                    print("   No data points returned")
            else:
                print(f"❌ Failed to fetch market data: {market_data['error']}")
                return False
            
            # Test getting ticker
            print("\n📈 Fetching BTCUSDT ticker...")
            ticker = await bybit.get_ticker("BTCUSDT")
            
            if ticker['success']:
                print("✅ Ticker data fetched successfully")
                ticker_data = ticker['data'].get('list', [])
                if ticker_data:
                    current = ticker_data[0]
                    print(f"   Current price: ${float(current['lastPrice']):,.2f}")
                    print(f"   24h change: {float(current['price24hPcnt'])*100:.2f}%")
                    print(f"   24h volume: {float(current['volume24h']):,.0f}")
                else:
                    print("   No ticker data returned")
            else:
                print(f"❌ Failed to fetch ticker: {ticker['error']}")
                return False
            
            # Test getting available symbols
            print("\n🔍 Fetching available symbols...")
            symbols = await bybit.get_available_symbols("linear")
            
            if symbols['success']:
                print("✅ Symbols fetched successfully")
                symbol_list = symbols['data'].get('list', [])
                print(f"   Total symbols available: {len(symbol_list)}")
                
                # Show some popular symbols
                popular_symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'ADAUSDT']
                available_symbols = [s['symbol'] for s in symbol_list]
                
                print("   Popular symbols available:")
                for symbol in popular_symbols:
                    if symbol in available_symbols:
                        print(f"     ✅ {symbol}")
                    else:
                        print(f"     ❌ {symbol}")
            else:
                print(f"❌ Failed to fetch symbols: {symbols['error']}")
                return False
            
            return True
            
    except Exception as e:
        print(f"❌ Error testing Bybit integration: {e}")
        return False

async def test_bybit_account_info():
    """Test Bybit account information (requires API keys)."""
    print("\n🧪 Testing Bybit Account Info...")
    
    # Check if API keys are configured
    if not Settings.BYBIT_API_KEY or not Settings.BYBIT_API_SECRET:
        print("⚠️  Bybit API keys not configured")
        print("   To test account features, add your API keys to .env file:")
        print("   BYBIT_API_KEY=your_api_key_here")
        print("   BYBIT_API_SECRET=your_api_secret_here")
        print("   BYBIT_TESTNET=true")
        return False
    
    try:
        async with BybitTradingTool(testnet=True) as bybit:
            print("📊 Fetching account information...")
            account_info = await bybit.get_account_info()
            
            if account_info['success']:
                print("✅ Account info fetched successfully")
                account_data = account_info['data']
                print(f"   Account type: {account_data.get('accountType', 'Unknown')}")
                
                # Show wallet balances
                wallet_list = account_data.get('list', [])
                if wallet_list:
                    wallet = wallet_list[0]
                    print(f"   Total wallet balance: {wallet.get('totalWalletBalance', 'Unknown')}")
                    print(f"   Available balance: {wallet.get('availableToWithdraw', 'Unknown')}")
                else:
                    print("   No wallet data available")
            else:
                print(f"❌ Failed to fetch account info: {account_info['error']}")
                return False
            
            return True
            
    except Exception as e:
        print(f"❌ Error testing account info: {e}")
        return False

async def test_bybit_order_placement():
    """Test Bybit order placement (paper trading only)."""
    print("\n🧪 Testing Bybit Order Placement (Paper Trading)...")
    
    if not Settings.BYBIT_API_KEY or not Settings.BYBIT_API_SECRET:
        print("⚠️  Skipping order placement test - API keys not configured")
        return True
    
    try:
        async with BybitTradingTool(testnet=True) as bybit:
            print("📝 Testing order placement (will not execute)...")
            
            # Test order placement with minimal quantity
            order_result = await bybit.place_order(
                symbol="BTCUSDT",
                side="Buy",
                order_type="Market",
                qty=0.001,  # Minimal quantity
                time_in_force="GTC"
            )
            
            if order_result['success']:
                print("✅ Order placement test successful")
                order_data = order_result['data']
                print(f"   Order ID: {order_data.get('orderId', 'Unknown')}")
                print(f"   Order status: {order_data.get('orderStatus', 'Unknown')}")
                
                # Cancel the test order
                if order_data.get('orderId'):
                    print("🔄 Cancelling test order...")
                    cancel_result = await bybit.cancel_order(
                        symbol="BTCUSDT",
                        order_id=order_data['orderId']
                    )
                    
                    if cancel_result['success']:
                        print("✅ Test order cancelled successfully")
                    else:
                        print(f"⚠️  Failed to cancel test order: {cancel_result['error']}")
            else:
                print(f"❌ Order placement test failed: {order_result['error']}")
                return False
            
            return True
            
    except Exception as e:
        print(f"❌ Error testing order placement: {e}")
        return False

async def main():
    """Main test function."""
    print("🚀 Testing Bybit Integration")
    print("=" * 50)
    
    # Test 1: Market data
    market_test = await test_bybit_market_data()
    
    # Test 2: Account info
    account_test = await test_bybit_account_info()
    
    # Test 3: Order placement
    order_test = await test_bybit_order_placement()
    
    print("\n" + "=" * 50)
    print("🎉 Bybit Integration Test Results")
    print("\n📋 Summary:")
    print(f"✅ Market data: {'PASS' if market_test else 'FAIL'}")
    print(f"✅ Account info: {'PASS' if account_test else 'SKIP'}")
    print(f"✅ Order placement: {'PASS' if order_test else 'SKIP'}")
    
    if market_test:
        print("\n🎯 Bybit integration is working with the market!")
        print("📊 Can fetch real-time market data")
        print("📈 Can get ticker information")
        print("🔍 Can access available trading symbols")
        
        if account_test and order_test:
            print("💰 Full trading capabilities available")
        else:
            print("💡 Add API keys to enable full trading features")
    else:
        print("\n❌ Bybit integration needs attention")
        print("🔧 Check network connection and API endpoints")

if __name__ == "__main__":
    asyncio.run(main()) 